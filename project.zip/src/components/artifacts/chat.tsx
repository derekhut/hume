"use client";

import { useCallback, useEffect, useState } from "react";
import { CodeOutlined, SendOutlined } from '@ant-design/icons';
import { Spin, Avatar, Input, Empty, Space } from "antd"
import { useChat } from "ai/react";
import { Button } from "@/components/ui/button";
import Markdown from "@/components/markdown/markdown";
import { Card, CardContent } from "@/components/ui/card";
import { Upload, Button as AntdButton, Image } from "antd";
import { InboxOutlined } from "@ant-design/icons";
import { CloseOutlined } from '@ant-design/icons';
import { RobotOutlined } from '@ant-design/icons';

type Message = {
  role: string;
  content: any;
  id: string;
};

const Artifact = ({
  title,
  loading = false,
  handleClick,
}: {
  title: string;
  loading?: boolean;
  handleClick?: () => void
}) => (
  <Card className="w-full max-w-sm bg-background border border-border ml-5" onClick={handleClick}>
    <CardContent className="flex items-center gap-3 p-3">
      <div className="bg-muted rounded-md p-2">
        {loading ? (
          <Spin className="h-5 w-5 text-foreground" />
        ) : (
          <CodeOutlined className="h-5 w-5 text-foreground" />
        )}
      </div>
      <div className="flex-1">
        <p className="text-sm font-medium text-foreground">{title}</p>
        <p className="text-xs text-muted-foreground">
          {loading ? "Generating..." : "Click to open component"}
        </p>
      </div>
    </CardContent>
  </Card>
);

const ChatMessage = ({ message, loadingArtifact }: { message: Message, loadingArtifact: boolean }) => {
  const isUser = message.role === "user";
  return (
    <div className={`flex items-start gap-3 ${isUser ? "justify-end" : ""}`}>
      {!isUser && (
        <Space>
          <Avatar className="h-8 w-8 border border-gray-200 bg-white text-gray-700 shadow-sm">
            AI
          </Avatar>
          {
            loadingArtifact && (
              <>
                <Artifact title="Loading Artifact..." loading={true} />
                <br/>
              </>
            )
          }
        </Space>
      )}
      {
        !loadingArtifact && (
          <div
            className={`${
                isUser
              ? "bg-blue-500 text-white shadow-sm"
              : "bg-gray-50 text-gray-700 border border-gray-100 shadow-sm"
            } max-w-[70%] rounded-lg px-4 py-3`}
          >
            <Markdown text={typeof message.content === "string" ? message.content : message.content?.[1]?.text} />
          </div>
        )
      }
      {isUser && (
        <Avatar className="h-8 w-8 border border-gray-200 bg-white text-gray-700 shadow-sm">
          You
        </Avatar>
      )}
    </div>
  );
};

export function ClientChat({
  setArtifactContent,
  setIsCodeLoading,
  historyCode,
  setCurrentPage
}: {
  setArtifactContent: (content: string) => void;
  setIsCodeLoading: (loading: boolean) => void;
  historyCode: string[];
  setCurrentPage: (val:number) => void;
}) {
  const { messages, input, setInput, append, isLoading } = useChat();
  const [parsedMessages, setParsedMessages] = useState<Message[]>([]);
  const [artifactInfo, setArtifactInfo] = useState<Record<string,any>>({});
  const [currentArtifact, setCurrentArtifact] = useState<string | null>(null);
  const [isThinking, setIsThinking] = useState(false);
  const [imageBase64, setImageBase64] = useState<string | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);

  const parseMessage = useCallback((message: Message) => {
    let content = typeof message.content === "string" ? message.content : message.content?.[0]?.text;

    // Check for thinking tags
    if (content.includes("<antthinking>")) {
      setIsThinking(true);
    }
    if (content.includes("</antthinking>")) {
      setIsThinking(false);
    }

    if(typeof content === "string"){
      // Remove thinking tags and their content
      content = content.replace(/<antthinking>.*?<\/antthinking>/gs, "");
    }

    // Handle artifact tags
    const artifactStartIndex = content.indexOf("<antartifact");
    const artifactEndIndex = content.indexOf("</antartifact>");

    if (artifactStartIndex !== -1) {
      const artifactContent = content.slice(
        content.indexOf(">", artifactStartIndex) + 1
      );
      setArtifactContent(artifactContent);
      if (artifactEndIndex !== -1) {
        const artifactContent = content.slice(
          content.indexOf(">", artifactStartIndex) + 1,
          artifactEndIndex
        );
        setArtifactContent(artifactContent);
        artifactInfo[message.id] = artifactContent
        setArtifactInfo(artifactInfo);
        setIsCodeLoading(false);
        content =
          content.slice(0, artifactStartIndex) +
          content.slice(artifactEndIndex + "</antartifact>".length);
      } else {
        setCurrentArtifact(content.slice(artifactStartIndex));
        setIsCodeLoading(true);
        content = content.slice(0, artifactStartIndex);
      }
    } else if (currentArtifact) {
      if (artifactEndIndex !== -1) {
        // End of artifact
        const fullArtifact =
          currentArtifact + content.slice(0, artifactEndIndex);
        const artifactContent = fullArtifact.slice(
          fullArtifact.indexOf(">") + 1
        );
        setArtifactContent(artifactContent);
        content = content.slice(artifactEndIndex + "</antartifact>".length);
      } else {
        // Continuing artifact
        setCurrentArtifact(currentArtifact + content);
        content = "";
      }
    }

    // Update parsed messages if there's content
    if (content && !isThinking) {
      setParsedMessages((prevMessages) => {
        const existingIndex = prevMessages.findIndex(
          (m) => m.id === message.id
        );
        if (existingIndex !== -1) {
          const updatedMessages = [...prevMessages];
          updatedMessages[existingIndex] = {
            ...message,
            content: content,
          };
          return updatedMessages;
        } else {
          return [...prevMessages, { ...message, content: content }];
        }
      });
    }
  },[currentArtifact, isThinking, setArtifactContent, setIsCodeLoading]);

  useEffect(() => {
    if (messages.length > 0) {
      const lastMessage = messages[messages.length - 1]!;
      parseMessage(lastMessage);
    }
  }, [messages, parseMessage]);
  
  const handleSend = () => {
    if (input.trim()) {
      let inputContent: any = input.trim()
      if(imageBase64){
        inputContent = [
          {
            "type": "text",
            "text": input.trim()
          },
          {
            "type": "image",
            "image": imageBase64,
          },
        ]
      }
      append({ content: inputContent, role: "user" });
      setCurrentArtifact("")
      setInput("");
      setImageBase64("")
      setImagePreview("")
    }
  };

  const beforeUpload = (file: Blob) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      setImageBase64(e.target?.result ?? '');
      setImagePreview(e.target.result);
    };
    reader.readAsDataURL(file);
    // 阻止上传
    return false;
  };

  const handleRemoveImage = () => {
    setImageBase64(null);
    setImagePreview(null);
  };

  const handleKeyDown = (e:any) => {
    if (e.key === 'Enter') {
      if(!e.shiftKey){
        e.preventDefault();
        handleSend()
      }
    }
  };

  const handlePaste = (event: React.ClipboardEvent<HTMLTextAreaElement>) => {
    const items = event.clipboardData.items;
    for (let i = 0; i < items.length; i++) {
      if (items[i].type.indexOf("image") !== -1) {
        const blob = items[i].getAsFile();
        const reader = new FileReader();
        reader.onload = (e) => {
          setImageBase64(e.target?.result ?? "");
          setImagePreview(e.target?.result ?? "");
        };
        reader.readAsDataURL(blob);
        break;
      }
    }
  };

  return (
    <div className="flex h-full flex-col">
      <div className="bg-white border-b border-gray-100 p-4 flex justify-between items-center">
        <h2 className="text-lg font-medium">AI</h2>
      </div>
      <div className="flex-1 overflow-auto p-4">
        <div className="grid gap-6">
          {parsedMessages.length === 0 ? (
            (
              <div className="h-full flex items-center justify-center">
                <Empty
                  image={Empty.PRESENTED_IMAGE_SIMPLE}
                  description={
                    <span className="text-gray-500">
                      暂无聊天记录
                    </span>
                  }
                />
              </div>
            )
          ) : (
            parsedMessages.map((message, index) => (
              <>
                <ChatMessage key={message.id} message={message} loadingArtifact={currentArtifact && isLoading && index === parsedMessages.length - 1}/>
                {artifactInfo[message.id] && !isLoading && (
                  <Artifact title="Click to Open" handleClick={() => {
                    setArtifactContent(artifactInfo[message.id])
                    setCurrentPage(historyCode.findIndex(item=>item === artifactInfo[message.id]) + 1)
                  }}/>
                )}
              </>
            ))
          )}
          <div className="ml-5">
            {isLoading && !currentArtifact && (
              <Spin className="size-5 animate-spin" />
            )}
          </div>
        </div>
      </div>
      <div className="bg-white border-t border-gray-100 shadow-sm px-4 py-4">
        {imagePreview && (
          <div className="relative mb-3">
            <Image
              src={imagePreview}
              alt="Preview"
              style={{ width: 100, height: 100 }}
              preview={{ src: imagePreview }}
              className="rounded-lg border border-gray-200 shadow-sm"
            />
            <CloseOutlined 
              onClick={handleRemoveImage}
              className="absolute top-2 right-2 bg-white rounded-full p-1 shadow-md cursor-pointer hover:bg-gray-50 transition-colors"
              style={{ fontSize: 12 }}
            />
          </div>
        )}
        <div className="flex items-center gap-3">
          <Upload
            accept="image/*"
            showUploadList={false}
            beforeUpload={beforeUpload}
          /> 
          <Input.TextArea
            placeholder="请输入...... 按shift+Enter换行"
            className="flex-1 rounded-lg border-gray-200 hover:border-blue-400 focus:border-blue-500 transition-colors"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            autoSize={{ minRows: 1, maxRows: 6 }}
            onKeyDown={handleKeyDown}
            onPaste={handlePaste}
          />
          <Button
            type="submit"
            size="default"
            className="bg-blue-500 hover:bg-blue-600 text-white rounded-full px-6 py-2 flex items-center gap-2 transition-colors shadow-sm hover:shadow"
            onClick={handleSend}
          >
            <SendOutlined className="h-4 w-4" />
            发送
          </Button>
        </div>
      </div>
    </div>
  );
}