import { systemPrompt } from "@/app/api/chat/prompt";
import { createOpenAI } from '@ai-sdk/openai';
import { CoreMessage, streamText } from "ai";
import { RateLimiter } from "limiter";

const limiter = new RateLimiter({ tokensPerInterval: 6, interval: "minute" });

export async function POST(req: Request) {
  // 检查是否还有可用的令牌
  const remainingRequests = await limiter.removeTokens(1);
  
  if (remainingRequests < 0) {
    return new Response('Rate limit exceeded', { status: 429 });
  }

  try {
    const { messages }: { messages: CoreMessage[] } = await req.json();
    const slicedMessages = messages.slice(-5);
    console.log(slicedMessages)
    const hasImageMessage = slicedMessages.some(msg => {
      if (Array.isArray(msg.content)) {
        return msg.content.some(item => item.type === 'image');
      }
      return false;
    });
    const openai = createOpenAI({
      baseURL:"http://10.30.70.91:3000/v1", 
    });
    const result = await streamText({
      model: openai(hasImageMessage ? "gpt-4o" : "gpt-4"),
      system: systemPrompt,
      messages: slicedMessages,
    });
    return result.toAIStreamResponse();
  } catch (error) {
    console.error('Error:', error);
    return new Response('An error occurred', { status: 500 });
  }
}