"use client";

import { ClientChat } from "@/components/artifacts/chat";
import { Playground } from "@/components/artifacts/playground";
import React, { Suspense, useEffect, useState } from "react";
import {
  ResizableHandle,
  ResizablePanel,
  ResizablePanelGroup,
} from "@/components/ui/resizable";
import { useSearchParams } from "next/navigation";

const initialCode = `

import React, { useState, useEffect } from 'react';
import styled, { keyframes } from 'styled-components';

const fadeIn = keyframes\`
  from { opacity: 0; }
  to { opacity: 1; }
\`;


const Container = styled.div\`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  height: 100%;
  padding: 20px;
  background-color: #f0f0f0;
  animation: \${fadeIn} 2s ease-in;
\`;

const Title = styled.h1\`
  font-size: 2rem;
  color: #333;
  margin-bottom: 20px;
  text-align: center;
\`;

const AnimatedComponent = () => {
  return (
    <Container>
      <Title>Artifacts Preview</Title>
    </Container>
  );
};

export default AnimatedComponent;
`;


function PageContent() {
  const [code, setCode] = React.useState(initialCode);
  const [historyCode, setHistoryCode] = React.useState<any>([]);
  const [currentPage, setCurrentPage] = React.useState(1);
  const [isCodeLoading, setIsCodeLoading] = React.useState(false);
  const [isPreview, setIsPreview] = useState(false);
  const searchParams = useSearchParams();
  useEffect(() => {
    setIsPreview(searchParams.get('preview') === '1');
  }, [searchParams]);
  useEffect(() => {
    if(!isCodeLoading){
      const newCode = [...historyCode]
      newCode.push(code)
      setHistoryCode(newCode);
    }
  },[isCodeLoading]);
  useEffect(() => {
    const handleMessage = (event: MessageEvent) => {
      console.log('eventData', event.data)
      if (typeof event.data === 'object' && event.data !== null && event.data.html) {
        setCode(event.data.html);
      }
    };
    window.addEventListener("message", handleMessage);
    return () => {
      window.removeEventListener("message", handleMessage);
    };
  }, []);
  return (
    <div className="h-screen bg-gray-50">
      <ResizablePanelGroup direction="horizontal" className="h-full rounded-lg overflow-hidden">
        {!isPreview && (
          <ResizablePanel defaultSize={30} minSize={20}>
            <div className="overflow-auto h-full bg-white shadow-sm">
              <ClientChat
                historyCode={historyCode}
                setArtifactContent={setCode}
                setIsCodeLoading={setIsCodeLoading}
                setCurrentPage={setCurrentPage}
              />
            </div>
          </ResizablePanel>
        )}
        <ResizableHandle className="w-2 bg-gray-100 hover:bg-gray-200 transition-colors group relative cursor-col-resize">
          <div className="absolute inset-y-0 left-1/2 -translate-x-1/2 w-2 opacity-100">
            <div className="absolute inset-y-0 left-1/2 -translate-x-1/2 flex flex-col items-center justify-center gap-2">
              <div className="w-1.5 h-16 flex flex-col justify-center items-center gap-2">
                <div className="w-1.5 h-1.5 rounded-full bg-gray-400 group-hover:bg-blue-500 transition-colors"></div>
                <div className="w-1.5 h-1.5 rounded-full bg-gray-400 group-hover:bg-blue-500 transition-colors"></div>
                <div className="w-1.5 h-1.5 rounded-full bg-gray-400 group-hover:bg-blue-500 transition-colors"></div>
              </div>
            </div>
            <div className="absolute top-1/2 left-1/2 -translate-y-1/2 -translate-x-1/2">
              <div className="opacity-0 group-hover:opacity-100 transition-opacity bg-blue-500/20 rounded-full py-2 px-3 whitespace-nowrap">
                <div className="text-blue-500 rotate-90 text-xs">拖拽调整宽度</div>
              </div>
            </div>
          </div>
        </ResizableHandle>
        <ResizablePanel defaultSize={50} minSize={30}>
          <div className="overflow-auto h-full bg-white shadow-sm">
            <Playground 
              initialCode={code} 
              setCode={setCode} 
              historyCode={historyCode} 
              isCodeLoading={isCodeLoading} 
              currentPage={currentPage}
              setCurrentPage={setCurrentPage}
              isPreview={isPreview}
            />
          </div>
        </ResizablePanel>
      </ResizablePanelGroup>
    </div>
  );
}

export default function Page() {
  return (
    <Suspense fallback={<div>Loading...</div>}>
      <PageContent />
    </Suspense>
  );
}